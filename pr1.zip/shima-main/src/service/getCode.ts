const CODES_URL = "https://nikostin.pythonanywhere.com/api/codes/";

const getCode = async () => {
  try {
  } catch (error) {}
};
