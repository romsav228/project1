import calculator from "./calculator.js";
import validator from "./validator.js";

const string = process.argv[2];

console.log(calculator(string));
